
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 01/26/2020 08:51:44
-- Generated from EDMX file: C:\Users\dac\Desktop\FleetManagement\FleetManagement\Model1.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [fleetfinal];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_carcategorycar]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[cars] DROP CONSTRAINT [FK_carcategorycar];
GO
IF OBJECT_ID(N'[dbo].[FK_cityhub]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[hubs] DROP CONSTRAINT [FK_cityhub];
GO
IF OBJECT_ID(N'[dbo].[FK_employeebilling]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[billings] DROP CONSTRAINT [FK_employeebilling];
GO
IF OBJECT_ID(N'[dbo].[FK_hubemployee]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[employees] DROP CONSTRAINT [FK_hubemployee];
GO
IF OBJECT_ID(N'[dbo].[FK_registeruserbooking]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[bookings] DROP CONSTRAINT [FK_registeruserbooking];
GO
IF OBJECT_ID(N'[dbo].[FK_statecity]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[cities] DROP CONSTRAINT [FK_statecity];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[amenities]', 'U') IS NOT NULL
    DROP TABLE [dbo].[amenities];
GO
IF OBJECT_ID(N'[dbo].[billings]', 'U') IS NOT NULL
    DROP TABLE [dbo].[billings];
GO
IF OBJECT_ID(N'[dbo].[bookings]', 'U') IS NOT NULL
    DROP TABLE [dbo].[bookings];
GO
IF OBJECT_ID(N'[dbo].[carcategories]', 'U') IS NOT NULL
    DROP TABLE [dbo].[carcategories];
GO
IF OBJECT_ID(N'[dbo].[cars]', 'U') IS NOT NULL
    DROP TABLE [dbo].[cars];
GO
IF OBJECT_ID(N'[dbo].[cities]', 'U') IS NOT NULL
    DROP TABLE [dbo].[cities];
GO
IF OBJECT_ID(N'[dbo].[employees]', 'U') IS NOT NULL
    DROP TABLE [dbo].[employees];
GO
IF OBJECT_ID(N'[dbo].[hubs]', 'U') IS NOT NULL
    DROP TABLE [dbo].[hubs];
GO
IF OBJECT_ID(N'[dbo].[registerusers]', 'U') IS NOT NULL
    DROP TABLE [dbo].[registerusers];
GO
IF OBJECT_ID(N'[dbo].[states]', 'U') IS NOT NULL
    DROP TABLE [dbo].[states];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'amenities'
CREATE TABLE [dbo].[amenities] (
    [amenitiesid] int IDENTITY(1,1) NOT NULL,
    [amenitiesname] nvarchar(max)  NOT NULL,
    [amenitiesrate] decimal(18,0)  NOT NULL
);
GO

-- Creating table 'billings'
CREATE TABLE [dbo].[billings] (
    [billid] int IDENTITY(1,1) NOT NULL,
    [employeeempid] int  NOT NULL,
    [startdate] datetime  NOT NULL,
    [enddate] datetime  NOT NULL,
    [billfirstname] nvarchar(max)  NOT NULL,
    [billlastname] nvarchar(max)  NOT NULL,
    [address] nvarchar(max)  NOT NULL,
    [aadharno] nvarchar(max)  NOT NULL,
    [phoneno] nvarchar(max)  NOT NULL,
    [dailyrate] decimal(18,0)  NOT NULL,
    [weeklyrate] decimal(18,0)  NOT NULL,
    [monthlyrate] decimal(18,0)  NOT NULL,
    [fuelstatus] nvarchar(max)  NOT NULL,
    [bstatus] nvarchar(max)  NOT NULL,
    [pickuplocation] nvarchar(max)  NOT NULL,
    [dropofflocation] nvarchar(max)  NOT NULL,
    [amenitiesname] nvarchar(max)  NOT NULL,
    [amenitiesrate] decimal(18,0)  NOT NULL,
    [totalamount] decimal(18,0)  NOT NULL,
    [bookingid] int  NULL,
    [cartype] nvarchar(max)  NULL
);
GO

-- Creating table 'bookings'
CREATE TABLE [dbo].[bookings] (
    [bookingid] int IDENTITY(1,1) NOT NULL,
    [registeruseruserid] int  NOT NULL,
    [bookingdate] datetime  NOT NULL,
    [bfirstname] nvarchar(max)  NOT NULL,
    [blastname] nvarchar(max)  NOT NULL,
    [bdob] datetime  NOT NULL,
    [baddress] nvarchar(max)  NOT NULL,
    [drivinglicenseno] nvarchar(max)  NOT NULL,
    [baadharno] nvarchar(max)  NOT NULL,
    [bpassportno] nvarchar(max)  NOT NULL,
    [phoneno1] nvarchar(max)  NOT NULL,
    [phoneno2] nvarchar(max)  NOT NULL,
    [emailid] nvarchar(max)  NOT NULL,
    [pickupdate] datetime  NOT NULL,
    [returndate] datetime  NOT NULL,
    [cartype] nvarchar(max)  NOT NULL,
    [pickuplocation] nvarchar(max)  NOT NULL,
    [dropofflocation] nvarchar(max)  NOT NULL,
    [amenetiesname] nvarchar(max)  NOT NULL,
    [amenitiesrate] decimal(18,0)  NOT NULL
);
GO

-- Creating table 'carcategories'
CREATE TABLE [dbo].[carcategories] (
    [categoryid] int IDENTITY(1,1) NOT NULL,
    [imgpath] nvarchar(max)  NOT NULL,
    [carcategoryname] nvarchar(max)  NOT NULL,
    [dailyrate] decimal(18,0)  NOT NULL,
    [weeklyrate] decimal(18,0)  NOT NULL,
    [monthlyrate] decimal(18,0)  NOT NULL
);
GO

-- Creating table 'cars'
CREATE TABLE [dbo].[cars] (
    [carid] int IDENTITY(1,1) NOT NULL,
    [carnumberplate] nvarchar(max)  NOT NULL,
    [color] nvarchar(max)  NOT NULL,
    [capacity] int  NOT NULL,
    [carname] nvarchar(max)  NOT NULL,
    [mileage] int  NOT NULL,
    [avalibility] nvarchar(max)  NOT NULL,
    [carcategorycategoryid] int  NOT NULL,
    [hubhubid] int  NOT NULL
);
GO

-- Creating table 'cities'
CREATE TABLE [dbo].[cities] (
    [cityid] int IDENTITY(1,1) NOT NULL,
    [cityname] nvarchar(max)  NOT NULL,
    [statestateid] int  NOT NULL
);
GO

-- Creating table 'employees'
CREATE TABLE [dbo].[employees] (
    [empid] int IDENTITY(1,1) NOT NULL,
    [empname] nvarchar(max)  NOT NULL,
    [empdob] datetime  NOT NULL,
    [empaddress] nvarchar(max)  NOT NULL,
    [empphoneno] nvarchar(max)  NOT NULL,
    [empemailid] nvarchar(max)  NOT NULL,
    [emppanno] nvarchar(max)  NOT NULL,
    [hubhubid] int  NOT NULL
);
GO

-- Creating table 'hubs'
CREATE TABLE [dbo].[hubs] (
    [hubid] int IDENTITY(1,1) NOT NULL,
    [hubaddress] nvarchar(max)  NOT NULL,
    [hubphoneno] nvarchar(max)  NOT NULL,
    [airportcode] nvarchar(max)  NOT NULL,
    [citycityid] int  NOT NULL
);
GO

-- Creating table 'registerusers'
CREATE TABLE [dbo].[registerusers] (
    [userid] int IDENTITY(1,1) NOT NULL,
    [userfirstname] nvarchar(max)  NOT NULL,
    [userlastname] nvarchar(max)  NOT NULL,
    [userdob] datetime  NOT NULL,
    [userdrivinglicenceno] nvarchar(max)  NOT NULL,
    [useraadharno] nvarchar(max)  NOT NULL,
    [userpassportno] nvarchar(max)  NOT NULL,
    [userphoneno] nvarchar(max)  NOT NULL,
    [useremailid] nvarchar(max)  NOT NULL,
    [userpassword] nvarchar(max)  NOT NULL,
    [useraddress1] nvarchar(max)  NOT NULL,
    [useraddress2] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'states'
CREATE TABLE [dbo].[states] (
    [stateid] int IDENTITY(1,1) NOT NULL,
    [statename] nvarchar(max)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [amenitiesid] in table 'amenities'
ALTER TABLE [dbo].[amenities]
ADD CONSTRAINT [PK_amenities]
    PRIMARY KEY CLUSTERED ([amenitiesid] ASC);
GO

-- Creating primary key on [billid] in table 'billings'
ALTER TABLE [dbo].[billings]
ADD CONSTRAINT [PK_billings]
    PRIMARY KEY CLUSTERED ([billid] ASC);
GO

-- Creating primary key on [bookingid] in table 'bookings'
ALTER TABLE [dbo].[bookings]
ADD CONSTRAINT [PK_bookings]
    PRIMARY KEY CLUSTERED ([bookingid] ASC);
GO

-- Creating primary key on [categoryid] in table 'carcategories'
ALTER TABLE [dbo].[carcategories]
ADD CONSTRAINT [PK_carcategories]
    PRIMARY KEY CLUSTERED ([categoryid] ASC);
GO

-- Creating primary key on [carid] in table 'cars'
ALTER TABLE [dbo].[cars]
ADD CONSTRAINT [PK_cars]
    PRIMARY KEY CLUSTERED ([carid] ASC);
GO

-- Creating primary key on [cityid] in table 'cities'
ALTER TABLE [dbo].[cities]
ADD CONSTRAINT [PK_cities]
    PRIMARY KEY CLUSTERED ([cityid] ASC);
GO

-- Creating primary key on [empid] in table 'employees'
ALTER TABLE [dbo].[employees]
ADD CONSTRAINT [PK_employees]
    PRIMARY KEY CLUSTERED ([empid] ASC);
GO

-- Creating primary key on [hubid] in table 'hubs'
ALTER TABLE [dbo].[hubs]
ADD CONSTRAINT [PK_hubs]
    PRIMARY KEY CLUSTERED ([hubid] ASC);
GO

-- Creating primary key on [userid] in table 'registerusers'
ALTER TABLE [dbo].[registerusers]
ADD CONSTRAINT [PK_registerusers]
    PRIMARY KEY CLUSTERED ([userid] ASC);
GO

-- Creating primary key on [stateid] in table 'states'
ALTER TABLE [dbo].[states]
ADD CONSTRAINT [PK_states]
    PRIMARY KEY CLUSTERED ([stateid] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [employeeempid] in table 'billings'
ALTER TABLE [dbo].[billings]
ADD CONSTRAINT [FK_employeebilling]
    FOREIGN KEY ([employeeempid])
    REFERENCES [dbo].[employees]
        ([empid])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_employeebilling'
CREATE INDEX [IX_FK_employeebilling]
ON [dbo].[billings]
    ([employeeempid]);
GO

-- Creating foreign key on [registeruseruserid] in table 'bookings'
ALTER TABLE [dbo].[bookings]
ADD CONSTRAINT [FK_registeruserbooking]
    FOREIGN KEY ([registeruseruserid])
    REFERENCES [dbo].[registerusers]
        ([userid])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_registeruserbooking'
CREATE INDEX [IX_FK_registeruserbooking]
ON [dbo].[bookings]
    ([registeruseruserid]);
GO

-- Creating foreign key on [carcategorycategoryid] in table 'cars'
ALTER TABLE [dbo].[cars]
ADD CONSTRAINT [FK_carcategorycar]
    FOREIGN KEY ([carcategorycategoryid])
    REFERENCES [dbo].[carcategories]
        ([categoryid])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_carcategorycar'
CREATE INDEX [IX_FK_carcategorycar]
ON [dbo].[cars]
    ([carcategorycategoryid]);
GO

-- Creating foreign key on [citycityid] in table 'hubs'
ALTER TABLE [dbo].[hubs]
ADD CONSTRAINT [FK_cityhub]
    FOREIGN KEY ([citycityid])
    REFERENCES [dbo].[cities]
        ([cityid])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_cityhub'
CREATE INDEX [IX_FK_cityhub]
ON [dbo].[hubs]
    ([citycityid]);
GO

-- Creating foreign key on [statestateid] in table 'cities'
ALTER TABLE [dbo].[cities]
ADD CONSTRAINT [FK_statecity]
    FOREIGN KEY ([statestateid])
    REFERENCES [dbo].[states]
        ([stateid])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_statecity'
CREATE INDEX [IX_FK_statecity]
ON [dbo].[cities]
    ([statestateid]);
GO

-- Creating foreign key on [hubhubid] in table 'employees'
ALTER TABLE [dbo].[employees]
ADD CONSTRAINT [FK_hubemployee]
    FOREIGN KEY ([hubhubid])
    REFERENCES [dbo].[hubs]
        ([hubid])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_hubemployee'
CREATE INDEX [IX_FK_hubemployee]
ON [dbo].[employees]
    ([hubhubid]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------