﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace FleetManagement.Controllers
{
    public class CarCategoryController : ApiController
    {
        private fleetnewEntities db = new fleetnewEntities();


        //TO GET CARS FROM CARCATEGORY ID
        // api/CarCategory/1
        public IEnumerable<car> Getcarcategory(int id)
        {
            var ct = (from c in db.cars.ToList()
                      where c.carcategorycategoryid.Equals(id)
                      select new car()
                      {
                          carid = c.carid,
                          carname = c.carname,
                          carcategorycategoryid = c.carcategorycategoryid
                      });
            return ct;
        }



        // GET api/CarCategory
        public IEnumerable<carcategory> Getcarcategories()
        {
           
            return db.carcategories.AsEnumerable();
        }

        //// GET api/CarCategory/5
        //public carcategory Getcarcategory(int id)
        //{
        //    carcategory carcategory = db.carcategories.Find(id);
        //    if (carcategory == null)
        //    {
        //        throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
        //    }

        //    return carcategory;
        //}

        // PUT api/CarCategory/5
        public HttpResponseMessage Putcarcategory(int id, carcategory carcategory)
        {
            if (!ModelState.IsValid)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }

            if (id != carcategory.categoryid)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            db.Entry(carcategory).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        // POST api/CarCategory
        public HttpResponseMessage Postcarcategory(carcategory carcategory)
        {
            if (ModelState.IsValid)
            {
                db.carcategories.Add(carcategory);
                db.SaveChanges();

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, carcategory);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = carcategory.categoryid }));
                return response;
            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }
        }

        // DELETE api/CarCategory/5
        public HttpResponseMessage Deletecarcategory(int id)
        {
            carcategory carcategory = db.carcategories.Find(id);
            if (carcategory == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            db.carcategories.Remove(carcategory);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK, carcategory);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}