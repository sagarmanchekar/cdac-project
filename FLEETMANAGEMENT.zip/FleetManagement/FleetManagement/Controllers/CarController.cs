﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace FleetManagement.Controllers
{
    public class CarController : ApiController
    {
        private fleetnewEntities db = new fleetnewEntities();


        //Gives car names by categoryid
        public IEnumerable<car> Getcarsbytype(int id)
        {
            IEnumerable<car> s1 = (from c in db.cars.ToList()
                             where c.carcategorycategoryid.Equals(id)
                             select new car ()
                             { 
                                carname=c.carname
                             });
            return s1;
            
        
        }


/***************************************************************************/
        // GET api/Car
        public IEnumerable<car> Getcars()
        {
            var cars = db.cars.Include(c => c.carcategory);
            return cars.AsEnumerable();
        }

        // GET api/Car/5
        public car Getcar(int id)
        {
            car car = db.cars.Find(id);
            if (car == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return car;
        }

        // PUT api/Car/5
        public HttpResponseMessage Putcar(int id, car car)
        {
            if (!ModelState.IsValid)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }

            if (id != car.carid)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            db.Entry(car).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        // POST api/Car
        public HttpResponseMessage Postcar(car car)
        {
            if (ModelState.IsValid)
            {
                db.cars.Add(car);
                db.SaveChanges();

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, car);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = car.carid }));
                return response;
            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }
        }

        // DELETE api/Car/5
        public HttpResponseMessage Deletecar(int id)
        {
            car car = db.cars.Find(id);
            if (car == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            db.cars.Remove(car);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK, car);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}