﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using FleetManagement.Models;

namespace FleetManagement.Controllers
{
    public class CityController : ApiController
    {

        private fleetnewEntities db = new fleetnewEntities();

        //to get only cities in particaular state
        public IEnumerable<city> Getcity(int id)
        {
            IEnumerable<city> ct = (from c in db.cities.ToList()
                                    where c.statestateid.Equals(id)
                                    select new city()
                                    {
                                        cityid = c.cityid,
                                        cityname = c.cityname
                                    });
            return ct;

        }


     
/************************************************************************/
        //public IEnumerable<hub> Gethub(int id)
        //{
        //    var ct = (from c in db.hubs.ToList()
        //              where c.hubid.Equals(id)
        //              select new hub()
        //              {
        //                  airportcode = c.airportcode
        //              });
        //    return ct;
        //}



        //// GET api/City
        //public IEnumerable<city> Getcities()
        //{
        //    var cities = db.cities.Include(c => c.state);
        //    return cities.AsEnumerable();
        //}

        //// GET api/City/5
        //public city Getcity(int id)
        //{
        //    city city = db.cities.Find(id);
        //    if (city == null)
        //    {
        //        throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
        //    }

        //    return city;
        //}

    //    // PUT api/City/5
    //    public HttpResponseMessage Putcity(int id, city city)
    //    {
    //        if (!ModelState.IsValid)
    //        {
    //            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
    //        }

    //        if (id != city.cityid)
    //        {
    //            return Request.CreateResponse(HttpStatusCode.BadRequest);
    //        }

    //        db.Entry(city).State = EntityState.Modified;

    //        try
    //        {
    //            db.SaveChanges();
    //        }
    //        catch (DbUpdateConcurrencyException ex)
    //        {
    //            return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
    //        }

    //        return Request.CreateResponse(HttpStatusCode.OK);
    //    }

    //    // POST api/City
    //    public HttpResponseMessage Postcity(city city)
    //    {
    //        if (ModelState.IsValid)
    //        {
    //            db.cities.Add(city);
    //            db.SaveChanges();

    //            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, city);
    //            response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = city.cityid }));
    //            return response;
    //        }
    //        else
    //        {
    //            return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
    //        }
    //    }

    //    // DELETE api/City/5
    //    public HttpResponseMessage Deletecity(int id)
    //    {
    //        city city = db.cities.Find(id);
    //        if (city == null)
    //        {
    //            return Request.CreateResponse(HttpStatusCode.NotFound);
    //        }

    //        db.cities.Remove(city);

    //        try
    //        {
    //            db.SaveChanges();
    //        }
    //        catch (DbUpdateConcurrencyException ex)
    //        {
    //            return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
    //        }

    //        return Request.CreateResponse(HttpStatusCode.OK, city);
    //    }

    //    protected override void Dispose(bool disposing)
    //    {
    //        db.Dispose();
    //        base.Dispose(disposing);
    //    }
    }
}