﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace FleetManagement.Controllers
{
    public class RegisterUserController : ApiController
    {
        private fleetnewEntities db = new fleetnewEntities();

        // GET api/RegisterUser
        public IEnumerable<registeruser> Getregisterusers()
        {
            return db.registerusers.AsEnumerable();
        }

        // GET api/RegisterUser/5
        public registeruser Getregisteruser(int id)
        {
            registeruser registeruser = db.registerusers.Find(id);
            if (registeruser == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return registeruser;
        }

        // PUT api/RegisterUser/5
        public HttpResponseMessage Putregisteruser(int id, registeruser registeruser)
        {
            if (!ModelState.IsValid)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }

            if (id != registeruser.userid)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            db.Entry(registeruser).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        // POST api/RegisterUser
        public HttpResponseMessage Postregisteruser(registeruser registeruser)
        {
            if (ModelState.IsValid)
            {
                db.registerusers.Add(registeruser);
                db.SaveChanges();

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, registeruser);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = registeruser.userid }));
                return response;
            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }
        }

        // DELETE api/RegisterUser/5
        public HttpResponseMessage Deleteregisteruser(int id)
        {
            registeruser registeruser = db.registerusers.Find(id);
            if (registeruser == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            db.registerusers.Remove(registeruser);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK, registeruser);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}