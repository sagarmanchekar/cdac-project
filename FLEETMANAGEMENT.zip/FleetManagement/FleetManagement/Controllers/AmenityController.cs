﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace FleetManagement.Controllers
{
    public class AmenityController : ApiController
    {
        private fleetnewEntities db = new fleetnewEntities();


        //Gives all Amenities
        // GET api/Amenity
        public IEnumerable<amenity> Getamenities()
        {
            return db.amenities.AsEnumerable();
        }


        // GET api/Amenity/5
        public amenity Getamenity(int id)
        {
            amenity amenity = db.amenities.Find(id);
            if (amenity == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }
            return amenity;
        }



        /********************************************************/
        // PUT api/Amenity/5
        public HttpResponseMessage Putamenity(int id, amenity amenity)
        {
            if (!ModelState.IsValid)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }

            if (id != amenity.amenitiesid)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            db.Entry(amenity).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        // POST api/Amenity
        public HttpResponseMessage Postamenity(amenity amenity)
        {
            if (ModelState.IsValid)
            {
                db.amenities.Add(amenity);
                db.SaveChanges();

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, amenity);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = amenity.amenitiesid }));
                return response;
            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }
        }

        // DELETE api/Amenity/5
        public HttpResponseMessage Deleteamenity(int id)
        {
            amenity amenity = db.amenities.Find(id);
            if (amenity == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            db.amenities.Remove(amenity);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK, amenity);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}