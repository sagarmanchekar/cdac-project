﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace FleetManagement.Controllers
{
    public class StateController : ApiController
    {
        private fleetnewEntities db = new fleetnewEntities();

        //to get all states name and id only 
        // GET api/State
        public IEnumerable<state> GetAllstates()
        {
            IEnumerable<state> ct = (from c in db.states.ToList() 
                                          select new state()
            {
                stateid=c.stateid,
                statename=c.statename
            
            }
            );
            return ct;
        }


/***************************************************************/
        //// GET api/State/5
        //public state Getstate(int id)
        //{
        //    state state = db.states.Find(id);
        //    if (state == null)
        //    {
        //        throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
        //    }

        //    return state;
        //}




        ////// get api/state
        //public IEnumerable<state> Getstates()
        //{
        //    return db.states.AsEnumerable();
        //}






        //// GET api/State/5
        //public state Getstate(int id)
        //{
        //    state state = db.states.Find(id);
        //    if (state == null)
        //    {
        //        throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
        //    }

        //    return state;
        //}



        // PUT api/State/5
        //public HttpResponseMessage Putstate(int id, state state)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
        //    }

        //    if (id != state.stateid)
        //    {
        //        return Request.CreateResponse(HttpStatusCode.BadRequest);
        //    }

        //    db.Entry(state).State = EntityState.Modified;

        //    try
        //    {
        //        db.SaveChanges();
        //    }
        //    catch (DbUpdateConcurrencyException ex)
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
        //    }

        //    return Request.CreateResponse(HttpStatusCode.OK);
        //}

        //// POST api/State
        //public HttpResponseMessage Poststate(state state)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.states.Add(state);
        //        db.SaveChanges();

        //        HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, state);
        //        response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = state.stateid }));
        //        return response;
        //    }
        //    else
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
        //    }
        //}

        //// DELETE api/State/5
        //public HttpResponseMessage Deletestate(int id)
        //{
        //    state state = db.states.Find(id);
        //    if (state == null)
        //    {
        //        return Request.CreateResponse(HttpStatusCode.NotFound);
        //    }

        //    db.states.Remove(state);

        //    try
        //    {
        //        db.SaveChanges();
        //    }
        //    catch (DbUpdateConcurrencyException ex)
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
        //    }

        //    return Request.CreateResponse(HttpStatusCode.OK, state);
        //}

        //protected override void Dispose(bool disposing)
        //{
        //    db.Dispose();
        //    base.Dispose(disposing);
        //}
    }
}