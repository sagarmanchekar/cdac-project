﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using FleetManagement.Models;

namespace FleetManagement.Controllers
{  
    public class LoginController : ApiController
    {
 
        private fleetnewEntities db = new fleetnewEntities();
        [HttpPost] 
        public IEnumerable<registeruser> PostLogin(Login l)
        {
            //registeruser lst = db.registerusers.FirstOrDefault();

            IEnumerable<registeruser> details = (from r in db.registerusers.ToList()
                                    where r.useremailid == l.useremailid
                                    && r.userpassword == l.userpassword
                                    select r);
                         //                 select new registeruser()
                         //{
                         //    userid = r.userid,
                         //    userfirstname = r.userfirstname,
                         //      userlastname=r.userlastname,
                         //      userdob=r.userdob,
                         //      useraadharno=r.useraadharno,
                         //      userdrivinglicenceno=r.userdrivinglicenceno,
                         //      userpassportno=r.userpassportno,
                         //      useraddress1=r.useraddress1,
                         //      useraddress2=r.useraddress2,
                         //      useremailid=r.useremailid,
                         //      userphoneno=r.userphoneno
                         //}).ToList();
            return details;



            /**************************************************************/
            //if (null==details)
            //{
            //    Console.WriteLine("wrong email id plzz login again"); 
            //}
            //else
            //{
            //    Console.WriteLine("success");
            //}


        }

      
    }
}
