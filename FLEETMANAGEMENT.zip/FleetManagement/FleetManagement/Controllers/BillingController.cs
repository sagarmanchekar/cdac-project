﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Objects.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace FleetManagement.Controllers
{
    public class BillingController : ApiController
    {
        private fleetnewEntities db = new fleetnewEntities();
        //public IEnumerable<int?> Postbilling(int id)
        //{
        //    IEnumerable<int?> abc = (from d in db.billings.ToList()             
        //    select SqlFunctions.DateDiff("days",b.enddate,b.startdate));
        //    return abc;
        //}

    //    // POST api/Billing
    //    public IEnumerable<billing> Postbilling(int id)
    //    {


    //        var b = (from c in db.bookings.ToList()
    //                 where c.bookingid.Equals(id)
    //                 select new billing
    //                 {
    //                     bookingid=c.bookingid,
                         
    //                     billfirstname = c.bfirstname,
    //                     billlastname = c.blastname,
                         
    //                 });

    //        foreach(var v in b)
    //        {
    //            billing b1=new billing();
    //            b1.billlastname=v.billlastname;
    //b1.billfirstname=v.billfirstname;
    //        db.billings.Add(b1);
    //        db.SaveChanges();
    //        }
           
    //        return b;
    //    }




        /****************************/
        // GET api/Billing
        public IEnumerable<billing> Getbillings()
        {
            var billings = db.billings.Include(b => b.employee);
            return billings.AsEnumerable();
        }

        // GET api/Billing/5
        public billing Getbilling(int id)
        {
            billing billing = db.billings.Find(id);
            if (billing == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return billing;
        }

        // PUT api/Billing/5
        public HttpResponseMessage Putbilling(int id, billing billing)
        {
            if (!ModelState.IsValid)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }

            if (id != billing.bookingid)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            db.Entry(billing).State = EntityState.Modified;

            try
            {
                billing.enddate = DateTime.Now;
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        //// PUT api/Billing/5
        //public HttpResponseMessage Putbilling(int id, billing billing)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
        //    }

        //    if (id != billing.billid)
        //    {
        //        return Request.CreateResponse(HttpStatusCode.BadRequest);
        //    }

        //    db.Entry(billing).State = EntityState.Modified;

        //    try
        //    {
        //        db.SaveChanges();
        //    }
        //    catch (DbUpdateConcurrencyException ex)
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
        //    }

        //    return Request.CreateResponse(HttpStatusCode.OK);
        //}


        // POST api/Billing
        public HttpResponseMessage Postbilling(billing billing)
        {
            if (ModelState.IsValid)
            {
                billing.startdate = DateTime.Now;
                db.billings.Add(billing);
                db.SaveChanges();

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, billing);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = billing.billid }));
                return response;
            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }
        }



        //*******************************************************************************///
        //// POST api/Billing

        //public HttpResponseMessage Postbilling(billing billing)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        // billing.startdate = DateTime.Now;
        //        //db.billings.Add(billing);
        //        //db.SaveChanges();

        //        //using (var ctx = new fleetnewEntities())
        //        //{
        //        db.billings.Add(new billing()
        //        {
        //            billid = billing.billid,
        //            employeeempid = billing.employeeempid,
        //            startdate = DateTime.Now,
        //            billfirstname = billing.billfirstname,
        //            billlastname = billing.billlastname,
        //            address = billing.address,
        //            aadharno = billing.aadharno,
        //            phoneno = billing.phoneno,
        //            bstatus = billing.bstatus,
        //            pickuplocation = billing.pickuplocation,
        //            dropofflocation = billing.dropofflocation,
        //            amenitiesname = billing.amenitiesname,
        //            amenitiesrate = billing.amenitiesrate,
        //            bookingid = billing.bookingid,

        //        });
        //        try
        //        {
        //            db.SaveChanges();
        //        }
        //        catch (DbUpdateConcurrencyException ex)
        //        {
        //            return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
        //        }
        //    }
        //    else
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
        //    }
        //}


        //*******************************************************************************///
    

        
   
        // DELETE api/Billing/5
        
        public HttpResponseMessage Deletebilling(int id)
        {
            billing billing = db.billings.Find(id);
            if (billing == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            db.billings.Remove(billing);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK, billing);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}