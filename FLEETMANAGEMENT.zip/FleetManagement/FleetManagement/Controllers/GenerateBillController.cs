﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using FleetManagement.Models;

namespace FleetManagement.Controllers
{
    public class GenerateBillController : ApiController
    {

        private fleetnewEntities db = new fleetnewEntities();
        DateTime start;
        DateTime end = DateTime.Now;
        static int amt;
        int month = 0, week = 0, day = 0, rem1 = 0;
        int monthrate, weekrate, dailyrate;
        [HttpGet]
        public int GenerateBill(int id)
        {
            IEnumerable<billing> ob = (from c in db.billings.ToList()
                                       where c.bookingid.Equals(id)
                                       select new billing()
                                       {
                                           startdate = c.startdate,
                                           enddate = c.enddate,
                                           monthlyrate = c.monthlyrate,
                                           weeklyrate = c.weeklyrate,
                                           dailyrate = c.dailyrate
                                       });

            foreach (billing obj in ob.ToList())
            {
                start = obj.startdate;
                monthrate = (int)obj.monthlyrate;
                weekrate = (int)obj.weeklyrate;
                dailyrate = (int)obj.dailyrate;
                //                end = obj.enddate;
            }

            TimeSpan t = end.Subtract(start);
            int nod = t.Days + 1;

            if (nod >= 30)
            {
                month = nod / 30;
                rem1 = nod % 30;
                if (rem1 >= 7)
                {
                    week = rem1 / 7;
                    day = rem1 % 7;
                }
                else
                {
                    day = rem1;
                }

            }

            else
                if (nod >= 7 && nod < 30)
                {
                    week = nod / 7;
                    rem1 = nod % 7;
                    day = rem1;
                }
                else
                {
                    day = nod;
                }
            amt = month * monthrate + week * weekrate + day * dailyrate;

            return amt;

        }

        public IEnumerable<billing> GenerateInvoice(int id)
        {
            IEnumerable<billing> ob = (from c in db.billings.ToList()
                                       where c.bookingid.Equals(id)
                                       select new billing()
                                       {
                                           bookingid = c.bookingid,
                                           billfirstname = c.billfirstname,
                                           billlastname = c.billlastname,
                                           aadharno = c.aadharno,
                                           address = c.address,
                                           totalamount = amt
                                       });
            return ob;
        }
    }
}







