﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace FleetManagement.Controllers
{
    public class BookingController : ApiController
    {
        private fleetnewEntities db = new fleetnewEntities();

        //GET booking object by bookingid
        // GET api/Booking
        public IEnumerable<billing> Getbookings(int id)
        {
        var b = (from c in db.bookings.ToList()
                 where c.bookingid.Equals(id)
                            select new billing()
                            {
                               bookingid= c.bookingid,
                                billfirstname=c.bfirstname,
                                billlastname=c.blastname,
                                address=c.baddress,
                                aadharno=c.baadharno,
                                phoneno=c.phoneno2,
                                pickuplocation=c.pickuplocation,
                                dropofflocation=c.dropofflocation,
                                amenitiesname=c.amenetiesname,
                                amenitiesrate=c.amenitiesrate,
                             
                            });
            return b;
        }



        //// GET api/Booking
        //public IEnumerable<booking> Getbookings()
        //{
        //    var bookings = db.bookings.Include(b => b.registeruser);
        //    return bookings.AsEnumerable();
        //}


        // GET api/Booking/5
        public booking Getbooking(int id)
        {
            booking booking = db.bookings.Find(id);
            if (booking == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return booking;
        }

        // PUT api/Booking/5
        public HttpResponseMessage Putbooking(int id, booking booking)
        {
            if (!ModelState.IsValid)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }

            if (id != booking.bookingid)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }

            db.Entry(booking).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        // POST api/Booking
        public HttpResponseMessage Postbooking(booking booking)
        {
            booking.bookingdate = DateTime.Now;
            if (ModelState.IsValid)
            {
                db.bookings.Add(booking);
                db.SaveChanges();

                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, booking);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = booking.bookingid }));
                return response;
            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
            }
        }

        // DELETE api/Booking/5
        public HttpResponseMessage Deletebooking(int id)
        {
            booking booking = db.bookings.Find(id);
            if (booking == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            db.bookings.Remove(booking);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
            }

            return Request.CreateResponse(HttpStatusCode.OK, booking);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}