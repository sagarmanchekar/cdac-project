﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace FleetManagement.Controllers
{
    public class HubController : ApiController
    {
        private fleetnewEntities db = new fleetnewEntities();

       
        //to get only hub address by city id
        // GET api/City/1
        public IEnumerable<String> Gethubaddress(int id)
        {
            IEnumerable<String> ct = (from c in db.hubs
                                      where c.citycityid.Equals(id)
                                      select c.hubaddress);
            return ct;

        }

/****************************************************************/


        //To get hub obect from cityid
        //public IEnumerable<hub> Gethub(int id)
        //{
            
        //    IEnumerable<hub> ct = (from c in db.hubs.ToList()
        //                           where c.citycityid.Equals(id)
        //                           select new hub()
        //                           {
        //                               hubid = c.hubid,
        //                               hubaddress = c.hubaddress,
        //                               hubphoneno = c.hubphoneno
        //                           });
        //    return ct;
        //}


        //To get city obect from stateid
        //public IEnumerable<city> Getcity(int id)
        //{
        //    IEnumerable<city> ct = (from c in db.cities.ToList()
        //                            where c.statestateid.Equals(id)
        //                            select new city()
        //                            {
        //                                cityid = c.cityid,
        //                                cityname = c.cityname
        //                            });
        //    return ct;

        //}
        



        //// GET api/Hub
        //public IEnumerable<hub> Gethubs()
        //{
        //    var hubs = db.hubs.Include(h => h.city);
        //    return hubs.AsEnumerable();
        //}

        //// GET api/Hub/5
        //public hub Gethub(int id)
        //{
        //    hub hub = db.hubs.Find(id);
        //    if (hub == null)
        //    {
        //        throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
        //    }

        //    return hub;
        //}


        // PUT api/Hub/5
        //public HttpResponseMessage Puthub(int id, hub hub)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
        //    }

        //    if (id != hub.hubid)
        //    {
        //        return Request.CreateResponse(HttpStatusCode.BadRequest);
        //    }

        //    db.Entry(hub).State = EntityState.Modified;

        //    try
        //    {
        //        db.SaveChanges();
        //    }
        //    catch (DbUpdateConcurrencyException ex)
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
        //    }

        //    return Request.CreateResponse(HttpStatusCode.OK);
        //}

        //// POST api/Hub
        //public HttpResponseMessage Posthub(hub hub)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.hubs.Add(hub);
        //        db.SaveChanges();

        //        HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, hub);
        //        response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = hub.hubid }));
        //        return response;
        //    }
        //    else
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
        //    }
        //}

        //// DELETE api/Hub/5
        //public HttpResponseMessage Deletehub(int id)
        //{
        //    hub hub = db.hubs.Find(id);
        //    if (hub == null)
        //    {
        //        return Request.CreateResponse(HttpStatusCode.NotFound);
        //    }

        //    db.hubs.Remove(hub);

        //    try
        //    {
        //        db.SaveChanges();
        //    }
        //    catch (DbUpdateConcurrencyException ex)
        //    {
        //        return Request.CreateErrorResponse(HttpStatusCode.NotFound, ex);
        //    }

        //    return Request.CreateResponse(HttpStatusCode.OK, hub);
        //}

        //protected override void Dispose(bool disposing)
        //{
        //    db.Dispose();
        //    base.Dispose(disposing);
        //}
    }
}