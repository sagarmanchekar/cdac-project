import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './home/login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RegisterComponent } from './home/register/register.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { CarcateogaryComponent } from './carcateogary/carcateogary.component';
import { BookingComponent } from './booking/booking.component';

import { LoginselectComponent } from './home/loginselect/loginselect.component';
import { LoginstaffComponent } from './home/loginstaff/loginstaff.component';
import { BillingdetailsComponent} from './billingdetails/billingdetails.component';
import {StaffsearchComponent } from './staffsearch/staffsearch.component';
import { from } from 'rxjs';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    RegisterComponent,
    LoginComponent,
    CarcateogaryComponent,
    BookingComponent,
  
    LoginselectComponent,
    LoginstaffComponent,
    BillingdetailsComponent,
    StaffsearchComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    BsDatepickerModule,
    BsDatepickerModule.forRoot(),
    BsDropdownModule, ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
