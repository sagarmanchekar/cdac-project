import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginselectComponent } from './loginselect.component';

describe('LoginselectComponent', () => {
  let component: LoginselectComponent;
  let fixture: ComponentFixture<LoginselectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginselectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginselectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
