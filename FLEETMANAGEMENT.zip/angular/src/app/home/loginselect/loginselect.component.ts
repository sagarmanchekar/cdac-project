import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginselect',
  templateUrl: './loginselect.component.html',
  styleUrls: ['./loginselect.component.css']
})
export class LoginselectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
