import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Login } from 'src/app/shared/login';
import { LoginService } from 'src/app/shared/login.service';
import { Router } from '@angular/router';
import { Register } from 'src/app/shared/register';
import { RegisterService } from 'src/app/shared/register.service';
import { RegisterImpl } from 'src/app/shared/register-impl';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  model: any = {};
    reg: Register;
    reg1: any;
    loginForm: FormGroup;
    isSubmitted  =  false;
    temp: boolean;
  id: number;
  // tslint:disable-next-line:no-shadowed-variable
  constructor(private LoginService: LoginService , private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    localStorage.removeItem('USERNAME');
    localStorage.clear();

    this.loginForm  =  this.formBuilder.group({
      useremailid: ['', Validators.required],
      userpassword: ['', Validators.required]
  });
  }



  login() {

    this.temp = false;
    console.log(this.loginForm.value);


    this.reg = new RegisterImpl (null, '', '', null, '', '', '', '', '', '', '', '' );

    this.reg.useremailid = this.loginForm.controls.useremailid.value;
    this.reg.userpassword = this.loginForm.controls.userpassword.value;
    this.LoginService.Login(this.reg).subscribe((data) => { this.reg1 = data;
                                                            console.log(this.reg1);
                                                            if (this.reg1) {


         this.reg1.forEach(element => {
           console.log(element.userid);
           localStorage.setItem('userid', element.userid);
         });



         console.log(localStorage.getItem('userid'));
        // localStorage.setItem('ID', this.reg.userid);
        // this.router.navigate(['/home']);
      } else {
        alert('Wrong password');
        this.router.navigate(['/Login']);
      }
   });


}

}
