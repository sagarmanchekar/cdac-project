import { Component, OnInit } from '@angular/core';
import { HomeService } from '../shared/home.service';
import { State } from '../shared/state';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { City } from '../shared/city';
import { Hub } from '../shared/hub';
import { Booking } from '../shared/booking';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  homeForm: FormGroup;
  stateobj: State;
  cityvar: City[];
  cityvar1: City[];
  hubvar = [];
  hubvar1 = [];
  stateid: number;
  cityid: number;
  statevar: State[];
  statevar1: State[];
  flag: string;
  cityobj: City;
  bobj: Booking[];
  objb: any;


  constructor(public fb: FormBuilder, private service: HomeService, private router: Router) { }


  ngOnInit() {
    this.buildHomeForm();
    this.service.getState().subscribe(
    data => this.statevar = data
   );
  }
  buildHomeForm() {
    this.homeForm = this.fb.group({
      stateobj: ['', [Validators.required]],
      cityvar: ['', Validators.required],
      hubvar: ['', Validators.required],
      stateobj1: ['', [Validators.required]],
      cityvar1: ['', Validators.required],
      hubvar1: ['', Validators.required],
      pdate: ['', Validators.required]
    });

  }



  onSubmit(homeform: FormGroup) {

 localStorage.setItem('vita1', JSON.stringify(this.hubvar));
 localStorage.setItem('vita2', JSON.stringify(this.hubvar1));
 alert(localStorage.getItem( 'vita1' ));
 alert(localStorage.getItem( 'vita2' ));

 this.router.navigate(['/Carcateogary']);
  }
  onChangeState(stateid) {
    // tslint:disable-next-line:radix
    this.stateid = parseInt(stateid);
    for (const Obj of this.statevar) {
      if (Obj.stateid === this.stateid) {
        this.stateobj = Obj;
        break;
      }
    }
    // localStorage.setItem("abc",JSON.stringify(this.statevar));
   // console.log(localStorage.getItem('abc'));

    this.service.getCity(this.stateobj.stateid).subscribe(
         data => this.cityvar = data
    );

  }

  onChangeState1(stateid) {
    // tslint:disable-next-line:radix
    this.stateid = parseInt(stateid);
    for (const Obj of this.statevar) {
      if (Obj.stateid === this.stateid) {
        this.stateobj = Obj;
        break;
      }
    }
    // localStorage.setItem("abc",JSON.stringify(this.statevar));
   // console.log(localStorage.getItem('abc'));

    this.service.getCity(this.stateobj.stateid).subscribe(
         data => this.cityvar1 = data
    );

  }




  onChangeCity(id) {
    alert(id);
    // tslint:disable-next-line:radix
    this.cityid = parseInt(id);

    // for(var Obj of this.cityvar)
    // {
    //   if(Obj.cityid === this.cityid)
    //   {
    //     this.cityobj = Obj;
    //     break;
    //   }
    // }

    this.service.getHub(this.cityid).subscribe(
      data => {this.hubvar = data; console.log(this.hubvar); }    );




      // localStorage.setItem("vita",JSON.stringify(this.hubvar))
      // console.log(localStorage.getItem("vita"))
    localStorage.setItem('hub', JSON.stringify(this.hubvar));

    console.log(localStorage.getItem('hub'));
  }

  onChangeCity1(id) {
  this.service.getHub(id).subscribe(
    data => {this.hubvar1 = data; console.log(this.hubvar1);  } );

  localStorage.setItem('hub1', JSON.stringify(this.hubvar1));
  console.log(localStorage.getItem('hub1'));
}
}
