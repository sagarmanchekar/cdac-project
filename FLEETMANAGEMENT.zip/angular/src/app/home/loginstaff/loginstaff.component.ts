import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Employee } from 'src/app/shared/employee';
import { EmployeeImpl } from 'src/app/shared/employee-impl';
import { EmployeeService } from 'src/app/shared/employee.service';

@Component({
  selector: 'app-loginstaff',
  templateUrl: './loginstaff.component.html',
  styleUrls: ['./loginstaff.component.css']
})
export class LoginstaffComponent implements OnInit {

  model: any = {};
  reg: Employee;
  loginForm: FormGroup;
  isSubmitted  =  false;
  temp: boolean;
  reg1: any;
  // tslint:disable-next-line:no-shadowed-variable
  constructor(private EmployeeService: EmployeeService , private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    localStorage.removeItem('USERNAME');
    localStorage.clear();

    this.loginForm  =  this.formBuilder.group({
      empemailid: ['', Validators.required],
      empphoneno: ['', Validators.required]
  });
  }

  login() {

    this.temp = false;
    console.log(this.loginForm.value);


    this.reg = new EmployeeImpl (null, '', '', ' ', '', '', '', null );
    this.reg. empphoneno = this.loginForm.controls.empemailid.value;
    this.reg.empemailid = this.loginForm.controls.empphoneno.value;
    this.EmployeeService.Login(this.reg).subscribe((data) => {this.reg1 = data;
                                                              console.log(this.reg1);


                                                              if (data) {
        localStorage.setItem('USERNAME', this.loginForm.value.empemailid);
        localStorage.setItem('PASSWORD', this.loginForm.value.empphoneno);


        this.router.navigate(['/staffsearch']);
      } else {
        alert('Wrong password');
        this.router.navigate(['/Login']);
      }

   });


}

}
