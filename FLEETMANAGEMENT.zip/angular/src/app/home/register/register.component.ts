import { Component, OnInit } from '@angular/core';
import { RegisterService } from 'src/app/shared/register.service';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private service : RegisterService) { }

  ngOnInit() 
  {
    this.resetForm();
  }
   resetForm(form?: NgForm)
   {
     if(form!=null)
     form.resetForm();
     this.service.formData={
      userid : null,
      userfirstname : '',
      userlastname : '',
      userdob : null, 
      userdrivinglicenceno : '',
      useraadharno : '',
      userpassportno : '',
      userphoneno : '',
      useremailid : '',
      userpassword : '',
      useraddress1 : '',
      useraddress2 : ''
     }
   }
   onSubmit(form : NgForm)
   {
     
    this.insertRecord(form); 
   }
   insertRecord(form : NgForm)
   {
      this.service.postRegisteruser(form.value).subscribe(res =>
        {
          this.resetForm(form);
          this.service.refreshList();
      });
   }

   
}
