import { Component } from '@angular/core';
import { LoginService } from './shared/login.service';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  loginForm: FormGroup;
  constructor(private rout: Router, private formBuilder: FormBuilder) { }
  title = 'Demo';

  public logout() {
    alert('logout......................');
    localStorage.removeItem('USERNAME');
    localStorage.removeItem('PASSWORD');
    // this.rout.navigate(['Login']);
    this.rout.navigate(['home']);
}
 }
