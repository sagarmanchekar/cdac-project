import { Component, OnInit } from '@angular/core';
import { Billingdetails } from '../shared/billingdetails';
import { BillingdetailsService } from '../shared/billingdetails.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Booking } from '../shared/booking';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-billingdetails',
  templateUrl: './billingdetails.component.html',
  styleUrls: ['./billingdetails.component.css']
})
export class BillingdetailsComponent implements OnInit {
  showarr=[];
  bill:number;
  obj:any;
  // tslint:disable-next-line:variable-name
  constructor(private _empservice: BillingdetailsService, private _activatedRoute: ActivatedRoute, private route: Router) { }

  ngOnInit() {

    // const empCode: string = this._activatedRoute.snapshot.params.code;
    // // tslint:disable-next-line:radix
    // const acode: number = parseInt(empCode);
    this.bill=(parseInt(localStorage.getItem("id")))
    this._empservice.getEmployeeByCode(this.bill).subscribe(  (data) => 
    {
      this.obj = data 
    console.log(this.obj)
    this.showarr.push(this.obj)
    console.log(this.showarr)
  })

}
senddata()
{
  var v =document.getElementById("1").nodeValue;
  alert("Billing Confirm")
  this.route.navigate(['/staffsearch'])
  
}
}
