import { Component, OnInit } from '@angular/core';
import { NgForm, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-staffsearch',
  templateUrl: './staffsearch.component.html',
  styleUrls: ['./staffsearch.component.css']
})
export class StaffsearchComponent implements OnInit {
  num:any;
  clickMessage :string;
  values:number;
  constructor(private router: Router) { }

  ngOnInit() {
  }

  // tslint:disable-next-line:typedef-whitespace
  onSubmit(fc : FormGroup) {
   this.num =fc;
   alert();
 
   
  }


  onKey(event: any) { // without type info
    this.values = parseInt(event.target.value);
    console.log(this.values);
    localStorage.setItem("id",JSON.stringify(this.values));
    alert(localStorage.getItem("id"))
    this.router.navigate(['/billingsdetails']);
  }
}
