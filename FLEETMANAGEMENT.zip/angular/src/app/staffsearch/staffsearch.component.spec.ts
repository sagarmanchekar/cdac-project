import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffsearchComponent } from './staffsearch.component';

describe('StaffsearchComponent', () => {
  let component: StaffsearchComponent;
  let fixture: ComponentFixture<StaffsearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StaffsearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StaffsearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
