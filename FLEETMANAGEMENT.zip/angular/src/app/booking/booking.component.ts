import { Component, OnInit } from '@angular/core';
import { BookingservService } from '../shared/bookingserv.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
    temp:any 
  constructor(private service : BookingservService) { }

  ngOnInit() 
  {
    this.resetForm();
  }
   resetForm(form?: NgForm)
   {
     if(form!=null)
     form.resetForm();
     this.service.formData={
      bookingdate : null,
      bfirstname : '',
      blastname : '',
     bookingid:null,
      baddress: '',
      drivinglicenseno : '',
      baadharno : '',
      bpassportno : '',
      phoneno1: '',
      emailid: '',
      pickupdate : null,
      returndate: null,
      cartype: '',
      pickuplocation: '',
      dropofflocation: '',
      registeruseruserid: null,
      amenitiesrate: null,
      bdob: null,
      phoneno2: null

     }
   }
   onSubmit(form : NgForm)
   {
     
    this.insertRecord(form); 
   }
   insertRecord(form : NgForm)
   {
      this.service.postRegisteruser(form.value).subscribe(res =>
        {
          this.resetForm(form);
          this.service.refreshList();
          this.temp=res;
          alert(this.temp.bookingid)
          localStorage.setItem("bookingid",this.temp.bookingid);
      
          
      });
   }
}
