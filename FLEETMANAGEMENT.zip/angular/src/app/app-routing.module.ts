import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './home/register/register.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './home/login/login.component';
import { CarcateogaryComponent } from './carcateogary/carcateogary.component';
import { BookingComponent } from './booking/booking.component';

import { LoginselectComponent } from './home/loginselect/loginselect.component';
import { LoginstaffComponent } from './home/loginstaff/loginstaff.component';
import { BillingdetailsComponent } from './billingdetails/billingdetails.component';
import { StaffsearchComponent } from './staffsearch/staffsearch.component';


const routes: Routes = [
  { path: 'home', component: HomeComponent} ,
  {path: 'register', component: RegisterComponent},
  { path: 'loginSelect', component: LoginselectComponent} ,
  { path: 'Carcateogary', component: CarcateogaryComponent},
  {path: 'booking', component: BookingComponent},
  
  {path: 'login', component: LoginComponent},
  {path: 'loginstaff', component: LoginstaffComponent},
  {path: 'billingsdetails', component: BillingdetailsComponent},
  {path: 'staffsearch', component: StaffsearchComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
