import { Component, OnInit } from '@angular/core';
import { CarcateogaryService } from '../shared/carcateogary.service';
import { Router } from '@angular/router';
import { Carcateogary } from '../shared/carcateogary';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-carcateogary',
  templateUrl: './carcateogary.component.html',
  styleUrls: ['./carcateogary.component.css']
})
export class CarcateogaryComponent implements OnInit {
  constructor(private service: CarcateogaryService, private rout: Router) { }

  carhome: FormGroup;

  cartype: Carcateogary[];

  // tslint:disable-next-line:ban-types
  carvar: String[];

    localstorage;
  ngOnInit() {


      this.service.getCartype().subscribe(
      data => {this.cartype = data; console.log(this.cartype); }
     );



  }
  // tslint:disable-next-line:member-ordering

  call(a: string) {
    alert(a);

    localStorage.setItem(a, a);
   }
  onSubmit() {
       alert('helloooo');
       this.rout.navigate(['/booking']);
     }
}
