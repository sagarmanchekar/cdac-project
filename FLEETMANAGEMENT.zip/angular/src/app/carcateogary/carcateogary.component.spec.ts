import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CarcateogaryComponent } from './carcateogary.component';

describe('CarcateogaryComponent', () => {
  let component: CarcateogaryComponent;
  let fixture: ComponentFixture<CarcateogaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CarcateogaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CarcateogaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
