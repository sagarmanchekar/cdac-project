export interface Hub 
{
    hubid : number;
    hubaddress : string;
    hubphoneno : string;
    airportcode : string;
    citycityid : number;
}


