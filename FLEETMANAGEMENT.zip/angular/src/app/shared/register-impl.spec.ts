import { RegisterImpl } from './register-impl';

describe('RegisterImpl', () => {
  it('should create an instance', () => {
    expect(new RegisterImpl()).toBeTruthy();
  });
});
