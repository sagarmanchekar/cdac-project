import { Injectable } from '@angular/core';
import { Booking } from './booking';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BookingservService {
  [x: string]: any;

 


  formData: Booking;
  list:Booking[];
  readonly rootURL = 'http://localhost:52520/api/';
  constructor(private http: HttpClient) {

  }
  postRegisteruser(formData: Booking) {
    return this.http.post(this.rootURL + 'Booking/Postbooking', formData);
  }






  
  // putRegisteruser(formData: Booking) {
  //   return this.http.put(this.rootURL + 'RegisterUser/' + formData.userid, formData);
  // }

  // deleteRegisteruser(id: number) {
  //   return this.http.delete(this.rootURL + 'RegisterUser/' + id);
  // }

  // refreshList() {
  //   this.http.get(this.rootURL + '/RegisterUser')
  //   .toPromise().then(res => this.list = res as Register[]);
  // }


}
