import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Billingdetails } from './billingdetails';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BillingdetailsService {


  constructor(private http: HttpClient) { }

  url = 'http://localhost:52520/api/';



  getEmployeeByCode(code: any): Observable<Billingdetails> {
    console.log(this.url+"Booking/GetBooking"+code)
    return this.http.get<Billingdetails>(this.url + "Booking/GetBooking/"+code);
    alert("hello");
    }

    // public getEmployeeByCode(pid:number){

    //   return this.http.get<any>(this.url+"Booking/GetBooking/"+pid);
    // }


}
