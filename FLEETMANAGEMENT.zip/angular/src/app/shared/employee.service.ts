import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  readonly Url = 'http://localhost:52520/api/';
  constructor(private http: HttpClient, private rout: Router) { }

  Login(reg: Employee) {
        return  this.http.post<Employee>(this.Url + 'Employee/PostLogin/', reg);
  }

  public isLoggedIn() {
    console.log('In staff');
    return localStorage.getItem('USERNAME') !== null;

  }

}
