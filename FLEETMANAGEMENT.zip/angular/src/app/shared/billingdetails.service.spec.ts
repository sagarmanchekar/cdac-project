import { TestBed } from '@angular/core/testing';

import { BillingdetailsService } from './billingdetails.service';

describe('BillingdetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BillingdetailsService = TestBed.get(BillingdetailsService);
    expect(service).toBeTruthy();
  });
});
