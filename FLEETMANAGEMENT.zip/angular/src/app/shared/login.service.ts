import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Register } from './register';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  readonly Url = 'http://localhost:52520/api/';
  constructor(private http: HttpClient, private rout: Router) { }

  Login(reg: Register) {
        return  this.http.post<Register>(this.Url + 'Login/PostLogin/', reg);
  }

  public isLoggedIn() {
    console.log('hello');
    return localStorage.getItem('USERNAME') !== null;

  }


  }


