import { Billingdetails } from './billingdetails';

export class BillingdetailsImpl implements Billingdetails
{
     constructor
     
    (
       public bookingid : number,
       public billfirstname : string,
       public billlastname : string,
       public address : string,
       public cartype : string,
       public aadharno: string,
       public phoneno : string,
       public pickuplocation : string,
       public dropofflocation : string,
       public amenitiesname : string,
       public amenitiesrate : number
    )
    {}
     
     
}

