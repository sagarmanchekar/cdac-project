// tslint:disable-next-line:no-empty-interface
export interface Booking {
bookingid: number;
registeruseruserid: number ;
bookingdate: Date ;
bfirstname: string ;
blastname: string ;
bdob: Date ;
baddress: string ;
drivinglicenseno: string ;
baadharno: string ;
bpassportno: string ;
phoneno1: string;
phoneno2: string ;

emailid: string;
pickupdate: Date;
returndate: Date;
cartype: string ;
pickuplocation: string ;
dropofflocation: string;
amenitiesrate: number ;
}
