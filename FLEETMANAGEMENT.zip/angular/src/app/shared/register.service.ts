import { Injectable } from '@angular/core';
import { Register } from './register';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  formData: Register;
  list: Register[];
  readonly rootURL = 'http://localhost:52520/api/';
  constructor(private http: HttpClient) {

  }
  postRegisteruser(formData: Register) {
    return this.http.post(this.rootURL + 'RegisterUser/Postregisteruser', formData);
  }

  putRegisteruser(formData: Register) {
    return this.http.put(this.rootURL + 'RegisterUser/' + formData.userid, formData);
  }

  deleteRegisteruser(id: number) {
    return this.http.delete(this.rootURL + 'RegisterUser/' + id);
  }

  refreshList() {
    this.http.get(this.rootURL + '/RegisterUser')
    .toPromise().then(res => this.list = res as Register[]);
  }

}
