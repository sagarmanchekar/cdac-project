import { Employee } from './employee';

export class EmployeeImpl implements Employee {
    constructor
   // tslint:disable-next-line:space-before-function-paren
   (
        public empid: number,
        public empname: string,
        public empdob: string,
        public empaddress: string,
        public empphoneno: string,
        public empemailid: string,
        public emppanno: string,
        public hubhubid: number

    ) {}
}

