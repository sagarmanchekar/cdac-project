export interface Employee
{
  [x: string]: any;
    empid : number;
    empname : string;
    empdob : string;
    empaddress : string;
    empphoneno : string;
    empemailid : string;
    emppanno : string;
    hubhubid : number;
}
