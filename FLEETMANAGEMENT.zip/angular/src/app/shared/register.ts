export interface Register {
    userid: number;
    userfirstname: string;
    userlastname: string;
    userdob: Date;
    userdrivinglicenceno: string;
    useraadharno: string;
    userpassportno: string;
    userphoneno: string;
    useremailid: string;
    userpassword: string;
    useraddress1: string;
    useraddress2: string;
}
