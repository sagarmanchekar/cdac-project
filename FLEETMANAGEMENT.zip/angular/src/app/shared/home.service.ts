import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { State } from './state';
import { City } from './city';
import { Hub } from './hub';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  // this.http.get(this.rootURL+'/RegisterUser')
  //   .toPromise().then(res => this.list = res as Registeruser[]);




  readonly url = 'http://localhost:52520/api';
  constructor(private http: HttpClient) { }
  getState(): Observable<State[]> {
    return this.http.get<State[]>(this.url + '/State/GetAllstates');
  }

  // tslint:disable-next-line:variable-name
  getCity(seg_id): Observable<City[]> {
    // tslint:disable-next-line:radix
    seg_id = parseInt(seg_id);
    // return this.http.get<Imanufacturer[]>(`${this.url}Customers/${seg_id}`);
    return this.http.get<City[]>(this.url + '/City/Getcity/' + seg_id);
  }

  // tslint:disable-next-line:ban-types
  getHub(id: number): Observable<String[]> {

    // return this.http.get<Imodel>(`${this.url}Select/?mid=${manu_id}&sid=${seg_id}`);
    // tslint:disable-next-line:ban-types
    return this.http.get<String[]>(this.url + '/Hub/Gethubaddress/' + id);

  }


}
