import { TestBed } from '@angular/core/testing';

import { BookingservService } from './bookingserv.service';

describe('BookingservService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BookingservService = TestBed.get(BookingservService);
    expect(service).toBeTruthy();
  });
});
