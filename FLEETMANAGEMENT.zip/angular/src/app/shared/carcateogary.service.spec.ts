import { TestBed } from '@angular/core/testing';

import { CarcateogaryService } from './carcateogary.service';

describe('CarcateogaryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CarcateogaryService = TestBed.get(CarcateogaryService);
    expect(service).toBeTruthy();
  });
});
