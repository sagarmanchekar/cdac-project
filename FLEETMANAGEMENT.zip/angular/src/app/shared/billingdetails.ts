export interface Billingdetails {
    bookingid: number;
    billfirstname: string;
    billlastname: string;
    address: string;
    cartype: string;
    aadharno: string;
    phoneno: string;
    pickuplocation: string;
    dropofflocation: string;
    amenitiesname: string;
    amenitiesrate: number;
}



