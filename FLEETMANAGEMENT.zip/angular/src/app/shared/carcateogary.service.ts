import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Carcateogary } from './carcateogary';

@Injectable({
  providedIn: 'root'
})
export class CarcateogaryService {

  readonly url = 'http://localhost:52520/api/';
  constructor(private http: HttpClient) { }
  getCartype(): Observable<Carcateogary[]> {


    return this.http.get<Carcateogary[]>(this.url + 'CarCategory');
  }
}
