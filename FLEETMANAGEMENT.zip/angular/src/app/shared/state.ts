export interface State {
    stateid : number;
    statename  : string;
}
