import { BillingdetailsImpl } from './billingdetails-impl';

describe('BillingdetailsImpl', () => {
  it('should create an instance', () => {
    expect(new BillingdetailsImpl()).toBeTruthy();
  });
});
