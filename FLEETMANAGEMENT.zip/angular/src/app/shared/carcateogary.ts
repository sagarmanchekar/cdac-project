export interface Carcateogary {

    categoryid:number;
    imgpath: string;
    carcategoryname: string;
    dailyrate: number;
    weeklyrate: number;
    monthlyrate: number;

}
