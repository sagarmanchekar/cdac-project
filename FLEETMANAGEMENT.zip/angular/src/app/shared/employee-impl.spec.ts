import { EmployeeImpl } from './employee-impl';

describe('EmployeeImpl', () => {
  it('should create an instance', () => {
    expect(new EmployeeImpl()).toBeTruthy();
  });
});
