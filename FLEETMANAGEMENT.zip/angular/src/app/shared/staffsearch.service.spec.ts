import { TestBed } from '@angular/core/testing';

import { StaffsearchService } from './staffsearch.service';

describe('StaffsearchService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: StaffsearchService = TestBed.get(StaffsearchService);
    expect(service).toBeTruthy();
  });
});
