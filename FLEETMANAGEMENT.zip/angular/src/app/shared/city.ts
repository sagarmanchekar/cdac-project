export interface City {
    cityid: number;
    cityname: string;
    statestateid: number;
}


