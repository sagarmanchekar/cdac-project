import { Register } from './register';

export class RegisterImpl implements Register {
 constructor(
    public userid: number,
    public userfirstname: string,
    public userlastname: string,
    public userdob: Date,
    public userdrivinglicenceno: string,
    public useraadharno: string,
    public userpassportno: string,
    public userphoneno: string,
    public useremailid: string,
    public userpassword: string,
    public useraddress1: string,
    public  useraddress2: string
 ) {

 }
}
